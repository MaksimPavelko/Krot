import sqlite3

conn = sqlite3.connect("Рекорды.db")
curs = conn.cursor()

curs.execute("SELECT * FROM List_recordov")
rows = curs.fetchall()
print(rows)

curs.close()
conn.close()
